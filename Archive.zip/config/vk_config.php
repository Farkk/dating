<?php
// Конфигурация для авторизации через ВКонтакте
// ВАЖНО: Замените эти значения на свои из настроек приложения ВК
// Создать приложение: https://vk.com/apps?act=manage

define('VK_APP_ID', 'YOUR_VK_APP_ID');
define('VK_APP_SECRET', 'YOUR_VK_APP_SECRET');
define('VK_REDIRECT_URI', 'http://localhost:8000/auth/vk_callback.php');

// API версия
define('VK_API_VERSION', '5.131');
